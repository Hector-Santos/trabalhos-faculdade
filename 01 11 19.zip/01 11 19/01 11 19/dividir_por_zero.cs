﻿using OpenXmlPowerTools;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01_11_19
{
    class dividir_por_zero
    {
        int x, y;
        double result = 0;
        bool erro = false;

        Console.WriteLine("x=");
            X = int.Parse(Console.ReadLine());
        Console.WriteLine("y=");
            y = int.Parse(Console.ReadLine());

            try
            {
                result = x / y;
            }
            catch (DivideByZeroException)
            {
                Console.WriteLine("ERRO. Não é possível dividir por 0");
                erro = true;
            }
            if (erro == false)
            {
                Console.WriteLine("{0} dividido por {1} é {2}", x, y, result);
            }
            Console.ReadKey();
    }
    }
}
