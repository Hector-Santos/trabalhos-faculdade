﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01_11_19
{
    class Program
    {
        static void Main(string[] args)

        {
            double num, raiz;
            bool erro = false;

            Console.WriteLine("digite um numero");
            num = double.Parse(Console.ReadLine());
            try
            {
                raiz = tiraraiz(num);
            }
            catch (execaoderaizquadrada e)
            {
                Console.WriteLine("\n {0}", e.Message);
                erro = true;
               
            }

            if (!erro)
            {
                Console.WriteLine("A raiz quadrada de {0} é{1:f2}", num);
            }
            Console.ReadKey();
        }
        static double tiraraiz(double n)
        {
            if (n < 0)
                throw new execaoderaizquadrada("erro");
            return Math.Sqrt(n);
        }
        
    }
}
