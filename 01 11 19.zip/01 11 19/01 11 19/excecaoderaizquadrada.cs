﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01_11_19
{
    class execaoderaizquadrada: Exception
    {
        public execaoderaizquadrada(string message)
            : base(message)
        {

        }
    }
}
